'use client'

import { useState } from 'react'
// Change from @/ to relative paths
import ApplicationForm from '../../components/recruitment/ApplicationForm'
import OnboardingSteps from '../../components/recruitment/OnboardingSteps'
import TermsAndConditions from '../../components/recruitment/TermsAndConditions'

// Rest of the file stays the same
