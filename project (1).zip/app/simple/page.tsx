import Test from '../../components/test'

export default function SimplePage() {
  return <Test />
}
